@echo off
chcp 65001 >nul 2>&1
title WinRAR Activator
color 0E

echo ===================================================
echo             ACTIVATING WINRAR...
echo ===================================================
echo.

if exist "%~dp0rarreg.key" (
    echo [OK] Found offline 'rarreg.key'!
    echo Copying license to WinRAR folder...
    copy /y "%~dp0rarreg.key" "C:\Program Files\WinRAR\" >nul 2>&1
    echo [SUCCESS] WinRAR Activated Offline!
) else (
    echo [!] No offline key found. Attempting Online Activation...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://captainfahim7.github.io/WinRAR_Activator/WAS.ps1 | iex"
    echo [SUCCESS] Online Activation Process Completed!
)

echo.
echo ===================================================
echo             TASK FINISHED!
echo ===================================================
timeout /t 3 >nul
exit